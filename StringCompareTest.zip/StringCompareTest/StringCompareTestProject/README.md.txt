This Visual Studio project was created to test the standard C# string compare method.

The documentation for the method is located here: 
https://msdn.microsoft.com/en-us/library/7aaf32ef(v=vs.110).aspx�


Software
--------
Visual Studio Community 2017 version 15.4.2
SpecFlow for Visual Studio 2017
Microsoft Visual C# 2017


Test Development Process
------------------------
I used Visual Studio and NUnit as suggested by Lydia, and C# as the coding language.
From Visual Studio, create a Unit Test Project.
Install Specflow.NUnit to the project using the Package Manager Console.
Create a SpecFlow feature file.
Replace the sample feature file with my test implementation feature file.
Generate step definitions for the feature file, and implement my test code in C#.
Run the tests via the 'Run All' link in the Test Explorer.

Test Approach
-------------
1. Although there are many versions of the 'String.Compare' method, I tested 
   only the 6-parameter version documented on the URL provided.
2. I created 5 test scenarios:
   1) Success path scenarios for each of the 6 different StringComparison enum values.
      I used some examples from the StringComparison enum documentation page as well
      to confirm some results from that page.
   2) Exception scenarios which I could catch in the code.
   3) A null string to null string comparison. I could not pass a null string from
      the feature file, so I needed to create a test that assigned a null value in the 
      C# implementation code.
   4) Similarly, a null string to empty string comparison.
   5) Used the Turkish culture, to confirm the comments in the 'String.Compare'
      documentation noting that Turkish does not use linguistic casing rules.
3. Two exception scenarios occur at build time, and cause the Cucumber test case
   to fail:
   1) ArgumentOutofRangeException case where 'Either indexA or indexB is null, and
      length is greater than zero.'
   2) ArgumentException case: 'comparisonType is not a StringComparison value.
   I created a separate C# program to identify that the following errors occur
   for the call to 'String.Compare':
   Argument 2: cannot convert from '<null>' to 'int'
   Argument 6: cannot convert from 'System.StringComparison' to 'bool'.
   I also noted these errors when creating Cucumber scenario outline test cases
   with the invalid data. But I don't want scenarios in the Cucumber test suite
   where a test case fails; I can't 'catch' these particular error scenarios.
4. I set the baseline culture as 'en-US' to ensure test stability/portability.


Additional Comments
-------------------
1. I wrote a console application that printed the sort sequence for character sets
   for several culture types: invariant, ordinal, en-US, tr-TR.
   The purpose of this application was to show me the character sequence for the 
   various culture type, so that I could confirm that my 'String.Compare' tests
   were getting the expected results.



Observations
------------
The MS document for the string compare method contained an example using a 5-parameter version
of the method, even though the method documented on this page is a 6-parameter version.
I think that the example should have aligned with the method version documented on this page.



