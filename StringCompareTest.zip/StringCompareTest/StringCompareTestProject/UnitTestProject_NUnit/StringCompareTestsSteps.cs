﻿using System;
using TechTalk.SpecFlow;
using System.Globalization;
using System.Threading;
using NUnit.Framework;

// Description : This class tests that the C# string compare method is functioning to specifications:
// Spec to Test: https://msdn.microsoft.com/en-us/library/7aaf32ef(v=vs.110).aspx
// Written by  : Sean Smith
// Date        : Nov 6, 2017

namespace StringCompareTests
{
    [Binding]
    public class StringCompareTestSteps
    {
        // Set the culture that will be the baseine for testing.
        private const String baselineCultureString = "en-US";

        // Store the properties required to perform the 'String.Compare' test.
        private String string1ToCompare;
        private String string2ToCompare;
        private int numCharsToCompare;
        private int string1StartIndex;
        private int string2StartIndex;
        private StringComparison stringComparisonType;

        // Store the result of the 'String.Compare' operation.
        private int stringCompareResult;

        // Assign the 'String.Compare' result into one of the following categories:
        // ltzero: result is less than 0 - substring 1 is less than substring 2
        // gtzero: result is greater than 0 - substring 1 is greater than substring 2
        // eqzero: result is equal to zero - substring 1 is identical to substring 2
        // exception: an exception is expected to be raised due to invalid inputs
        private String stringCompareCategory;

        // Variable for testing different culture setting.
        private CultureInfo cultureSetting;

        // Store the current culture being used.
        private String cultureString;

        //  Initialize variables before each test is run.        
        [BeforeScenario]
        public void Initialize()
        {
            // Initialize properties.
            string1ToCompare = null;
            string2ToCompare = null;
            numCharsToCompare = 0;
            string1StartIndex = 0;
            string2StartIndex = 0;
            stringComparisonType = 0;
            stringCompareResult = 0;
            stringCompareCategory = null;
            cultureSetting = null;
            cultureString = null;

            // Set the culture to be used for testing.
            setBaselineCulture();

            // Let it be known the culture that is in use.
            Console.WriteLine("The current culture is \"{0}\".", cultureSetting.Name);
        }

        [Given(@"I have a string (.*)")]
        public void GivenIHaveAString(string string1)
        {
            // Get the first string which will be used for comparison.
            string1ToCompare = string1;
        }

        [Given(@"I take a substring of string1 starting from index (.*)")]
        public void GivenITakeASubstringOfString1FromIndex(int string1Index)
        {
            // Get the (0-based) substring index of the first string to be compared.
            string1StartIndex = string1Index;
        }

        [Given(@"I have another string (.*)")]
        public void GivenIHaveAnotherString(string string2)
        {
            // Get the second string which will be used for comparison.
            string2ToCompare = string2;
        }

        [Given(@"I take a substring of string2 starting from index (.*)")]
        public void GivenITakeASubstringOfString2FromIndex(int string2Index)
        {
            // Get the (0-based) substring index of the second string to be compared.
            string2StartIndex = string2Index;
        }

        [Given(@"I want to compare (.*) characters")]
        public void GivenIWantToCompareCharacters(int substr_length)
        {
            // Get the number of substring characters to compare from each string.
            numCharsToCompare = substr_length;
        }

        [Given(@"I will use comparison type (.*)")]
        public void GivenIWillUseComparisonType(StringComparison comparison_type)
        {
            // Assign the StringComparison enum value being used.
            stringComparisonType = comparison_type;
        }

        [When(@"I compare the substrings")]
        public void WhenICompareTheSubstrings()
        {
            // Set the culture that we need to be using for the test.
            cultureSetting = new CultureInfo(cultureString);
            Thread.CurrentThread.CurrentCulture = cultureSetting;

            // Get the current culture.
            CultureInfo nowCulture = Thread.CurrentThread.CurrentCulture;

            // Identify which culture is being used for the current test.
            Console.WriteLine("The culture used for the current test is \"{0}\".", nowCulture.Name);

            // Display the test property values for debugging.
            displayTestPropertyValues();

            // Exercise the 'String.Compare' operation against the 2 substrings, and retrieve the result of the operation, 
            // then categorize the result.
            // Ensure that exceptions are handled.
            try
            {
                // Perform the string comparison operation.
                stringCompareResult = String.Compare(string1ToCompare, string1StartIndex, string2ToCompare, string2StartIndex, numCharsToCompare,
                                                     stringComparisonType);

                // Categorize the result of the substring comparison.
                stringCompareCategory = ((stringCompareResult < 0) ? "ltzero" :
                                        ((stringCompareResult > 0) ? "gtzero" :
                                                                     "eqzero"));
            }
            catch (ArgumentOutOfRangeException aoor_exception)
            {
                // Identify that we caught an exception, so that we can compare with the expected test result.
                stringCompareCategory = "exception";
                Console.WriteLine("Caught ArgumentOutOfRangeException: {0}", aoor_exception);
            }

            // Reset culture to baseline.
            setBaselineCulture();

            // Display the stringCompareResult value for debugging.
            Console.WriteLine("stringCompareResult= {0}", stringCompareResult);
        }

        public void displayTestPropertyValues()
        {
            // Display the variables.
            Console.WriteLine("string1ToCompare= '{0}'", string1ToCompare);
            Console.WriteLine("string1StartIndex= {0}", string1StartIndex);
            Console.WriteLine("string2ToCompare= '{0}'", string2ToCompare);
            Console.WriteLine("string2StartIndex= {0}", string2StartIndex);
            Console.WriteLine("numCharsToCompare= {0}", numCharsToCompare);
            Console.WriteLine("stringComparisonType= {0}", stringComparisonType);
        }

        [Given(@"I have a null string")]
        public void GivenIHaveANullString()
        {
            // Set a null string for string1.
            string1ToCompare = null;
        }

        [Given(@"I have another null string")]
        public void GivenIHaveAnotherNullString()
        {
            // Set a null string for string2.
            string2ToCompare = null;
        }

        [Given(@"I want to verify the (.*) culture")]
        public void GivenIWantToVerifyDifferentCulture(String culture_string)
        {
            // Set the culture to be used for the test.
            cultureString = culture_string;
        }

        public void setBaselineCulture()
        {
            // Set the culture to use for testing.
            cultureSetting = new CultureInfo(baselineCultureString);
            Thread.CurrentThread.CurrentCulture = cultureSetting;

            // Assign the baseline culture to a string.
            cultureString = cultureSetting.Name;
        }

        [Then(@"the result should be (.*)")]
        public void ThenTheResultShouldBe(string expectedResult)
        {
            // Verify that the 'String.Compare' operation was successful.
            Assert.AreEqual(expectedResult, stringCompareCategory);
        }
    }
}
