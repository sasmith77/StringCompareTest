﻿using System;

namespace StringCompareException
{
    public class StringCompareExceptions
    {
        // Store the properties required to perform the 'String.Compare' test.
        private String string1ToCompare;
        private String string2ToCompare;
        private int numCharsToCompare;
        private int string1StartIndex;
        private int string2StartIndex;
        private StringComparison stringComparisonType;

        // Store the result of the 'String.Compare' operation.
        private int stringCompareResult;

        public void stringCompareTest()
        {
            //  Initialize variables for test, with invalid datatype for 
            // string1 index and for comparison type.        
            string1ToCompare = "abc";
            string2ToCompare = "def";
            numCharsToCompare = 3;
            string1StartIndex = null;
            string2StartIndex = 2;
            stringComparisonType = StringComparison.BadEnum;


            // Perform the string comparison operation.
            stringCompareResult = String.Compare(string1ToCompare, string1StartIndex, string2ToCompare, string2StartIndex, numCharsToCompare,
                                                 stringComparisonType);

        }

        static void Main(string[] args)
        {
            stringCompareTest();
        }
    }
}

