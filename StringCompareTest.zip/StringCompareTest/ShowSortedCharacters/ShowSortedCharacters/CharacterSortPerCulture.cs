﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;

// Description : This program prints out the character sort sequence for various culture types.
// Written by  : Sean Smith
// Date        : Nov 6, 2017

namespace ShowSortedCharacters
{
    class CharacterSortPerCulture
    {

        // This method prints out each character in sorted sequence.
        public static void Display(List<string> lst, string title)
        {
            Char c;
            Console.WriteLine(title);
            foreach (string s in lst)
            {
                c = s[0];
                Console.Write(c);
                Console.Write(" ");
            }
            Console.WriteLine();
        }


        static void Main(string[] args)
        {

            List<string> charList = new List<string>();

            // Initialize the character set to be sorted using different cultures.
            string[] items = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
                           "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
                           "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
                           "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                           "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                           "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "-", "_", "+", "=",
                           "{", "}", "[", "]", "|", "\\", ";", ":", "\"", "'", "-", "<", ">", ",", ".", "?", "/"
                         };

            // Load the string array with all of the characters.
            foreach (string str in items)
            {
                charList.Add(str);
            }

            // Get the culture that is associated with the current thread.
            CultureInfo thisCulture = Thread.CurrentThread.CurrentCulture;

            // Get the tr-TR (Turkish-Turkey) culture.
            CultureInfo turkish = new CultureInfo("tr-TR");

            // Get the en-US culture.
            CultureInfo US = new CultureInfo("en-US");


            // Get the standard StringComparers.
            StringComparer invCmp = StringComparer.InvariantCulture;
            //    StringComparer invICCmp = StringComparer.InvariantCultureIgnoreCase;
            StringComparer currCmp = StringComparer.CurrentCulture;
            //    StringComparer currICCmp = StringComparer.CurrentCultureIgnoreCase;
            StringComparer ordCmp = StringComparer.Ordinal;
            //    StringComparer ordICCmp = StringComparer.OrdinalIgnoreCase;
            // Create a StringComparer that uses the Turkish culture and ignores case.
            StringComparer turkICComp = StringComparer.Create(turkish, true);
            // Create a StringComparer that uses the US culture and ignores case.
            StringComparer USICComp = StringComparer.Create(US, true);


            // Display the original list order.
            Display(charList, "The original order of the list entries...");

            // Sort the list using the invariant culture.
            charList.Sort(invCmp);
            Display(charList, "Invariant culture...");

            // Sort the list using the current culture.
            Console.WriteLine("The current culture is \"{0}\".", thisCulture.Name);
            charList.Sort(currCmp);
            Display(charList, "Current culture...");

            // Sort the list using the US culture.
            charList.Sort(USICComp);
            Display(charList, "US culture");

            // Sort the list using the ordinal value of the character code points.
            charList.Sort(ordCmp);
            Display(charList, "Ordinal...");

            // Sort the list using the Turkish culture.
            charList.Sort(turkICComp);
            Display(charList, "Turkish culture");


            // Keep the console window open in debug mode.
            Console.WriteLine("Press any key to exit.");
           Console.ReadKey();
        }

    }
}
